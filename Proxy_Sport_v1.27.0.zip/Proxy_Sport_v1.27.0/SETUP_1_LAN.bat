@echo off
setlocal EnableExtensions
set "SRC=%~dp0helper\ProxySportHelper.exe"
set "DEST=%LOCALAPPDATA%\ProxySport"
set "EXE=%DEST%\ProxySportHelper.exe"
set "STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\ProxySportHelper.lnk"

if not exist "%SRC%" (
  echo [ERROR] Khong tim thay helper\ProxySportHelper.exe
  pause
  exit /b 1
)

if not exist "%DEST%" mkdir "%DEST%"

taskkill /F /IM ProxySportHelper.exe >nul 2>&1
copy /Y "%SRC%" "%EXE%" >nul
if errorlevel 1 (
  echo [ERROR] Khong copy duoc ProxySportHelper.exe
  pause
  exit /b 1
)

del /F /Q "%DEST%\ProxySportHelper.new.exe" >nul 2>&1
del /F /Q "%DEST%\ProxySportHelper_Update.cmd" >nul 2>&1

powershell -NoProfile -ExecutionPolicy Bypass -Command "$w=New-Object -ComObject WScript.Shell; $s=$w.CreateShortcut('%STARTUP%'); $s.TargetPath='%EXE%'; $s.WorkingDirectory='%DEST%'; $s.WindowStyle=7; $s.Save()"
if errorlevel 1 (
  echo [ERROR] Khong tao duoc Startup shortcut.
  pause
  exit /b 1
)

start "" "%EXE%"
timeout /t 1 /nobreak >nul
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $r=Invoke-RestMethod -UseBasicParsing http://127.0.0.1:19080/status -TimeoutSec 3; if($r.ok -and $r.version){ Write-Host ('[OK] Helper v' + $r.version + ' dang chay.'); exit 0 } else { exit 1 } } catch { exit 1 }"
if errorlevel 1 (
  echo [ERROR] Helper chua chay duoc. Thu chay lai SETUP_1_LAN.bat.
  pause
  exit /b 1
)

echo.
echo [OK] CAI DAT XONG - CHI CAN CHAY FILE NAY 1 LAN TREN MOI VPS.
echo Helper V1.27 co 4 lane va se tu kiem tra cap nhat tu GitHub.
echo Cac ban sau KHONG CAN chay lai Setup neu Helper tu cap nhat binh thuong.
echo.
echo Bay gio vao chrome://extensions ^> Reload PROXY SPORT neu dang mo Chrome.
echo.
pause
