const STORAGE_KEYS = {
  masterEnabled: "masterEnabled",
  proxyLine: "proxyLine",
  proxyLine2: "proxyLine2",
  /** "1" | "2" */
  activeProxySlot: "activeProxySlot",
  domainsText: "domainsText",
  ibetDomainsText: "ibetDomainsText",
  sbobetDomainsText: "sbobetDomainsText",
  ibetAgentDomains: "ibetAgentDomains",
  ibetMemberDomains: "ibetMemberDomains",
  sbobetAgentDomains: "sbobetAgentDomains",
  sbobetMemberDomains: "sbobetMemberDomains",
  /** Danh sách hiện tại do tải từ server — chỉ đọc, click mở web */
  domainsLockedFromFetch: "domainsLockedFromFetch",
};

/** Danh sách domain mặc định (mỗi dòng một mục, có thể dạng *.domain) */
const DOMAINS_LIST_URL =
  "https://raw.githubusercontent.com/luubi111666888/tool-updates/main/proxy-sport-domains.json";

const IBET_DOMAINS = [
  "*.14186vv.com",
  "*.025710.com",
  "*.nmcccc1.net",
  "*.litap88.com",
  "*.perpa88.com",
  "*.fika88.com",
];
const IBET_DOMAINS_TEXT = IBET_DOMAINS.join("\n");
const SBOBET_DOMAINS = [
  "agent.namnamvang.com",
  "agent.sbobet.com",
  "agent.senangmelompat.com",
  "balimassagecenter.com",
  "sbobong.com",
  "sbobet.com",
];
const SBOBET_DOMAINS_TEXT = SBOBET_DOMAINS.join("\n");

/**
 * Chuẩn hoá dòng domain (URL / host → *.apex, bỏ www.).
 * @param {string} raw
 * @returns {string}
 */
function normalizeDomainUserInput(raw) {
  let s = String(raw || "").trim();
  if (!s || s.startsWith("#")) {
    return "";
  }
  s = s.toLowerCase().replace(/\s+/g, "");
  if (/^\*\./.test(s) && !/:\/\//.test(s)) {
    const inner = s.slice(2).replace(/^www\./, "");
    return inner ? `*.${inner}` : "";
  }
  let host = "";
  if (/^[a-z][a-z0-9+.-]*:\/\//i.test(s)) {
    try {
      host = new URL(s).hostname;
    } catch {
      host = "";
    }
  } else {
    try {
      host = new URL(`https://${s}`).hostname;
    } catch {
      host = s.split("/")[0].split("?")[0].split("#")[0].split(":")[0];
    }
  }
  host = host.replace(/^\*\./, "").trim();
  if (!host) {
    return "";
  }
  if (host.startsWith("www.")) {
    host = host.slice(4);
  }
  return `*.${host}`;
}

/**
 * URL mở khi bấm vào dòng trong danh sách khóa.
 * @param {string} line ví dụ *.vnexpress.net
 */
function domainLineToOpenUrl(line) {
  let host = String(line || "")
    .trim()
    .toLowerCase()
    .replace(/^\*\./, "");
  if (!host) {
    return "about:blank";
  }
  if (/^https?:\/\//i.test(host)) {
    try {
      return new URL(host).href;
    } catch {
      return "about:blank";
    }
  }
  return `https://${host}/`;
}

function getActiveProxySlotFromForm() { return "1";
}

function getActiveProxyLineFromForm() {
  return getActiveProxySlotFromForm() === "2"
    ? $("proxyLine2").value
    : $("proxyLine").value;
}

function syncProxySlotRadios(slot) {
  const s = slot === "2" ? "2" : "1";
  const a = document.getElementById("proxySlot1");
  const b = document.getElementById("proxySlot2");
  if (a && b) {
    a.checked = s === "1";
    b.checked = s === "2";
  }
}

/** Lưu hai dòng proxy + slot (khi đổi Dòng 1/Dòng 2 — tự lưu và áp dụng PAC). */
async function persistProxyLinesAndSlot() {
  hideMessage();
  const slot = getActiveProxySlotFromForm();
  await chrome.storage.local.set({
    [STORAGE_KEYS.proxyLine]: $("proxyLine").value.trim(),
    [STORAGE_KEYS.proxyLine2]: $("proxyLine2").value.trim(),
    [STORAGE_KEYS.activeProxySlot]: slot,
  });
  try {
    const res = await chrome.runtime.sendMessage({ type: "APPLY_PROXY" });
    if (res && res.ok === false) {
      showMessage(res.error || "Không áp dụng proxy.", "err");
      return;
    }
    takeFormBaseline();
    showMessage("Đã lưu và áp dụng dòng đang chọn.", "ok");
  } catch (e) {
    showMessage(e instanceof Error ? e.message : String(e), "err");
    return;
  }
  chrome.runtime.sendMessage({ type: "REFRESH_ICON" }).catch(() => {});
}

function updateDomainsLockUi(locked) {
  const def = document.getElementById("domainsHintDefault");
  const loc = document.getElementById("domainsHintLocked");
  if (def && loc) {
    def.hidden = !!locked;
    loc.hidden = !locked;
  }
}

/** Danh sách domain khi khóa (đồng bộ snapshot) */
let domainsLockedState = false;
let lockedDomainsSnapshot = "";
/** Trạng thái đã lưu (để cảnh báo trước khi đóng popup) */
let baselineSnapshot = "";
let unsavedGuardEnabled = false;

function computeFormSnapshot() {
  const domPart = domainsLockedState
    ? lockedDomainsSnapshot
    : "subgroups";
  return JSON.stringify({
    p1: $("proxyLine").value,
    p2: $("proxyLine2").value,
    slot: getActiveProxySlotFromForm(),
    dom: domPart,
    m: $("masterSwitch").classList.contains("on") ? "1" : "0",
    dl: domainsLockedState ? "1" : "0",
  });
}

function takeFormBaseline() {
  baselineSnapshot = computeFormSnapshot();
}

function hasUnsavedChanges() {
  if (!unsavedGuardEnabled) {
    return false;
  }
  return computeFormSnapshot() !== baselineSnapshot;
}

function $(id) {
  const el = document.getElementById(id);
  if (!el) throw new Error("Missing #" + id);
  return el;
}

function showMessage(text, kind) {
  const msg = $("msg");
  msg.textContent = text;
  msg.className = "msg show " + (kind === "err" ? "err" : "ok");
}

function hideMessage() {
  const msg = $("msg");
  msg.className = "msg";
  msg.textContent = "";
}

/** Parse proxy — đồng bộ logic với background (kiểm tra sớm ở popup) */
function parseProxyLine(line) {
  const raw = String(line || "").trim();
  if (!raw) {
    throw new Error("Proxy trống.");
  }

  if (raw.includes("@")) {
    const at = raw.indexOf("@");
    const left = raw.slice(0, at).trim();
    const right = raw.slice(at + 1).trim();
    const colon = left.lastIndexOf(":");
    if (colon <= 0) {
      throw new Error('Định dạng host:port@user:pass không hợp lệ (thiếu ":" trước @).');
    }
    const host = left.slice(0, colon).trim();
    const port = left.slice(colon + 1).trim();
    const uc = right.indexOf(":");
    const user = uc >= 0 ? right.slice(0, uc) : right;
    const pass = uc >= 0 ? right.slice(uc + 1) : "";
    if (!host || !port) {
      throw new Error("host hoặc port không hợp lệ (dạng @).");
    }
    if (!/^\d+$/.test(port) || Number(port) < 1 || Number(port) > 65535) {
      throw new Error("Port không hợp lệ (1–65535).");
    }
    return { host, port, user, pass };
  }

  const parts = raw.split(":");
  if (parts.length < 2) {
    throw new Error('Cần ít nhất host:port hoặc host:port:user:pass.');
  }

  if (parts.length === 2) {
    const [host, port] = parts;
    if (!host || !port) throw new Error("host:port không hợp lệ.");
    if (!/^\d+$/.test(port) || Number(port) < 1 || Number(port) > 65535) {
      throw new Error("Port không hợp lệ (1–65535).");
    }
    return { host, port, user: "", pass: "" };
  }

  const host = parts[0];
  const port = parts[1];
  const user = parts[2];
  const pass = parts.slice(3).join(":");
  if (!host || !port) {
    throw new Error("host hoặc port không hợp lệ.");
  }
  if (!/^\d+$/.test(port) || Number(port) < 1 || Number(port) > 65535) {
    throw new Error("Port không hợp lệ (1–65535).");
  }
  return { host, port, user, pass };
}

function setMasterUi(on) {
  const sw = $("masterSwitch");
  sw.classList.toggle("on", on);
  sw.setAttribute("aria-checked", on ? "true" : "false");
  const label = document.getElementById("masterLabel");
  if (label) {
    label.textContent = on ? "Bật" : "Tắt";
    label.classList.toggle("master-label-active", on);
  }
}

/**
 * Số ô tối thiểu 4 (2 hàng × 2 cột); luôn có ít nhất một ô trống cuối để nhập thêm.
 * @param {string[]} vals Giá trị từng ô (bỏ qua ô trống liên tiếp ở cuối khi đếm)
 */
function computeDesiredCellCount(vals) {
  let v = [...vals];
  while (v.length && !v[v.length - 1].trim()) {
    v.pop();
  }
  const n = v.length;
  let cellCount = Math.max(4, n + 1);
  if (cellCount % 2 !== 0) {
    cellCount += 1;
  }
  return cellCount;
}

/**
 * @param {string} text domainsText trong storage
 * @returns {string[]}
 */
function textToCellValues(text) {
  let lines = String(text || "").split(/\r?\n/);
  while (lines.length && lines[lines.length - 1].trim() === "") {
    lines.pop();
  }
  const needed = computeDesiredCellCount(lines);
  const cells = [];
  for (let i = 0; i < needed; i++) {
    cells.push(lines[i] !== undefined ? lines[i] : "");
  }
  return cells;
}

/**
 * @param {string[]} cells
 * @param {number | null} focusIndex
 */
function renderDomainCells(cells, focusIndex) {
  const grid = $("domainsGrid");
  grid.classList.remove("domains-grid--locked");
  grid.replaceChildren();

  cells.forEach((value, idx) => {
    const cell = document.createElement("div");
    cell.className = "domain-cell";

    const num = document.createElement("span");
    num.className = "domain-num";
    num.textContent = `${idx + 1}.`;

    const input = document.createElement("input");
    input.type = "text";
    input.className = "domain-input";
    input.value = value;
    input.dataset.index = String(idx);
    input.autocomplete = "off";
    input.spellcheck = false;
    input.addEventListener("input", onDomainInput);
    input.addEventListener("blur", onDomainBlur);

    cell.appendChild(num);
    cell.appendChild(input);
    grid.appendChild(cell);
  });

  if (focusIndex != null && focusIndex >= 0) {
    const inp = grid.querySelector(`input.domain-input[data-index="${focusIndex}"]`);
    inp?.focus();
  }
}

function getDomainInputs() {
  return [...document.querySelectorAll("#domainsGrid .domain-input")];
}

function onDomainInput(e) {
  const inputs = getDomainInputs();
  const vals = inputs.map((i) => i.value);
  const idx = inputs.indexOf(/** @type {HTMLInputElement} */ (e.target));
  const needed = computeDesiredCellCount(vals);
  if (needed === inputs.length) {
    return;
  }
  const newCells = [...vals];
  while (newCells.length < needed) {
    newCells.push("");
  }
  newCells.length = needed;
  renderDomainCells(newCells, idx);
}

function onDomainBlur() {
  const inputs = getDomainInputs();
  const vals = inputs.map((i) => i.value);
  const needed = computeDesiredCellCount(vals);
  if (needed === inputs.length) {
    return;
  }
  const newCells = vals.slice(0, needed);
  while (newCells.length < needed) {
    newCells.push("");
  }
  renderDomainCells(newCells, null);
}

function getDomainsTextFromGrid() {
  const vals = getDomainInputs().map((i) => i.value.trim());
  while (vals.length && !vals[vals.length - 1]) {
    vals.pop();
  }
  return vals.join("\n");
}

/**
 * Danh sách tải về: 2 cột, số thứ tự, mỗi mục là link (không chỉnh sửa).
 * @param {string} text
 */
function renderRemoteDomainList(text) {
  const grid = $("domainsGrid");
  grid.classList.add("domains-grid--locked");
  grid.replaceChildren();

  const rawLines = String(text || "")
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);
  const lines = [];
  const seen = new Set();
  for (const raw of rawLines) {
    const norm = normalizeDomainUserInput(raw) || raw;
    const key = norm.replace(/^\*\./, "").toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    lines.push(norm);
  }

  lines.forEach((displayLine, idx) => {
    const cell = document.createElement("div");
    cell.className = "domain-cell domain-cell--locked";

    const num = document.createElement("span");
    num.className = "domain-num";
    num.textContent = `${idx + 1}.`;

    const a = document.createElement("a");
    a.className = "domain-link";
    a.href = domainLineToOpenUrl(displayLine);
    a.target = "_blank";
    a.rel = "noopener noreferrer";
    a.textContent = displayLine;
    a.title = `Mở ${a.href}`;

    cell.appendChild(num);
    cell.appendChild(a);
    grid.appendChild(cell);
  });

  if (lines.length % 2 === 1) {
    const pad = document.createElement("div");
    pad.className = "domain-cell domain-cell--locked domain-cell--pad";
    pad.setAttribute("aria-hidden", "true");
    grid.appendChild(pad);
  }
}


function uniqueNormalizedDomains(text) {
  const out = [];
  const seen = new Set();
  for (const raw of String(text || "").split(/\r?\n/)) {
    const norm = normalizeDomainUserInput(raw);
    if (!norm) continue;
    const key = norm.replace(/^\*\./, "").toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(norm);
  }
  return out;
}

function renderEditableLinkList(gridId, text, group) {
  const grid = $(gridId);
  grid.classList.add("domains-grid--locked");
  grid.replaceChildren();
  const lines = uniqueNormalizedDomains(text);
  lines.forEach((displayLine, idx) => {
    const cell = document.createElement("div");
    cell.className = "domain-cell domain-cell--locked";
    const num = document.createElement("span");
    num.className = "domain-num";
    num.textContent = `${idx + 1}.`;
    const a = document.createElement("a");
    a.className = "domain-link";
    a.href = domainLineToOpenUrl(displayLine);
    a.target = "_blank";
    a.rel = "noopener noreferrer";
    a.textContent = displayLine;
    const rm = document.createElement("button");
    rm.type = "button";
    rm.className = "domain-remove";
    rm.textContent = "×";
    rm.title = "XÓA LINK";
    rm.addEventListener("click", async (ev) => {
      ev.preventDefault();
      const key = group === "ibet" ? STORAGE_KEYS.ibetDomainsText : STORAGE_KEYS.sbobetDomainsText;
      const d = await chrome.storage.local.get(key);
      const cur = uniqueNormalizedDomains(d[key] || (group === "ibet" ? IBET_DOMAINS_TEXT : SBOBET_DOMAINS_TEXT));
      const target = displayLine.replace(/^\*\./, "").toLowerCase();
      const next = cur.filter(x => x.replace(/^\*\./, "").toLowerCase() !== target);
      await chrome.storage.local.set({ [key]: next.join("\n") });
      renderEditableLinkList(gridId, next.join("\n"), group);
      await chrome.runtime.sendMessage({ type: "APPLY_PROXY" });
      chrome.runtime.sendMessage({ type: "REFRESH_ICON" }).catch(() => {});
    });
    cell.append(num, a, rm);
    grid.appendChild(cell);
  });
  if (lines.length % 2 === 1) {
    const pad = document.createElement("div");
    pad.className = "domain-cell domain-cell--locked domain-cell--pad";
    pad.setAttribute("aria-hidden", "true");
    grid.appendChild(pad);
  }
}

async function addDomainFor(group) {
  hideMessage();
  const input = $(group === "ibet" ? "addIbetDomain" : "addSbobetDomain");
  const raw = input.value.trim();
  const norm = normalizeDomainUserInput(raw);
  if (!norm) {
    showMessage("LINK KHÔNG HỢP LỆ.", "err");
    return;
  }
  const key = group === "ibet" ? STORAGE_KEYS.ibetDomainsText : STORAGE_KEYS.sbobetDomainsText;
  const gridId = group === "ibet" ? "ibetDomainsGrid" : "sbobetDomainsGrid";
  const defaults = group === "ibet" ? IBET_DOMAINS_TEXT : SBOBET_DOMAINS_TEXT;
  const data = await chrome.storage.local.get(key);
  const cur = uniqueNormalizedDomains(data[key] || defaults);
  const target = norm.replace(/^\*\./, "").toLowerCase();
  if (!cur.some(x => x.replace(/^\*\./, "").toLowerCase() === target)) cur.push(norm);
  await chrome.storage.local.set({ [key]: cur.join("\n") });
  renderEditableLinkList(gridId, cur.join("\n"), group);
  input.value = "";
  const res = await chrome.runtime.sendMessage({ type: "APPLY_PROXY" });
  if (res && res.ok === false) {
    showMessage(res.error || "KHÔNG ÁP DỤNG ĐƯỢC PROXY.", "err");
    return;
  }
  showMessage(`ĐÃ THÊM LINK ${group.toUpperCase()}.`, "ok");
  chrome.runtime.sendMessage({ type: "REFRESH_ICON" }).catch(() => {});
}


const SUBGROUPS = {
  ibetAgent: { key: STORAGE_KEYS.ibetAgentDomains, grid: "ibetAgentGrid", input: "addIbetAgent", system: "ibet", defaults: ["*.litap88.com", "*.fika88.com"] },
  ibetMember: { key: STORAGE_KEYS.ibetMemberDomains, grid: "ibetMemberGrid", input: "addIbetMember", system: "ibet", defaults: ["*.025710.com", "*.14186vv.com"] },
  sbobetAgent: { key: STORAGE_KEYS.sbobetAgentDomains, grid: "sbobetAgentGrid", input: "addSbobetAgent", system: "sbobet", defaults: ["*.agent.namnamvang.com", "*.agent.senangmelompat.com"] },
  sbobetMember: { key: STORAGE_KEYS.sbobetMemberDomains, grid: "sbobetMemberGrid", input: "addSbobetMember", system: "sbobet", defaults: ["*.sbobong.com", "*.sbobet.com"] },
};
function listFromStored(v, defs){ const a=uniqueNormalizedDomains(v || defs.join("\n")); return a; }
async function syncCombinedDomainKeys(){
  const keys=Object.values(SUBGROUPS).map(x=>x.key); const d=await chrome.storage.local.get(keys);
  const ia=listFromStored(d[SUBGROUPS.ibetAgent.key],SUBGROUPS.ibetAgent.defaults), im=listFromStored(d[SUBGROUPS.ibetMember.key],SUBGROUPS.ibetMember.defaults);
  const sa=listFromStored(d[SUBGROUPS.sbobetAgent.key],SUBGROUPS.sbobetAgent.defaults), sm=listFromStored(d[SUBGROUPS.sbobetMember.key],SUBGROUPS.sbobetMember.defaults);
  await chrome.storage.local.set({[STORAGE_KEYS.ibetDomainsText]:[...ia,...im].join("\n"),[STORAGE_KEYS.sbobetDomainsText]:[...sa,...sm].join("\n")});
}
function renderSubgroup(name, lines){
  const cfg=SUBGROUPS[name], grid=$(cfg.grid); grid.replaceChildren();
  lines.slice(0,2).forEach((line,i)=>{ const row=document.createElement("div"); row.className="mini-domain-item";
    const n=document.createElement("span"); n.className="mini-num"; n.textContent=`${i+1}.`;
    const a=document.createElement("a"); a.className="mini-domain-link"; a.href=domainLineToOpenUrl(line); a.target="_blank"; a.rel="noopener"; a.textContent=line;
    const x=document.createElement("button"); x.className="mini-remove"; x.textContent="×"; x.title="XÓA"; x.onclick=async(e)=>{e.preventDefault(); const d=await chrome.storage.local.get(cfg.key); const cur=listFromStored(d[cfg.key],cfg.defaults); const next=cur.filter(v=>v!==line); await chrome.storage.local.set({[cfg.key]:next.join("\n")}); renderSubgroup(name,next); await syncCombinedDomainKeys(); await chrome.runtime.sendMessage({type:"APPLY_PROXY"});};
    row.append(n,a,x); grid.append(row); });
}
async function addSubgroup(name){ const cfg=SUBGROUPS[name], inp=$("addDomainInput"), norm=normalizeDomainUserInput(inp.value); if(!norm){showMessage("LINK KHÔNG HỢP LỆ.","err");return;} const d=await chrome.storage.local.get(cfg.key); const cur=listFromStored(d[cfg.key],cfg.defaults); if(cur.length>=2){showMessage("MỖI NHÓM TỐI ĐA 2 LINK. XÓA 1 LINK CŨ TRƯỚC.","err");return;} if(!cur.includes(norm))cur.push(norm); await chrome.storage.local.set({[cfg.key]:cur.join("\n")}); inp.value=""; renderSubgroup(name,cur); await syncCombinedDomainKeys(); await chrome.runtime.sendMessage({type:"APPLY_PROXY"}); showMessage("ĐÃ THÊM LINK.","ok"); }
async function loadSubgroups(){ const keys=Object.values(SUBGROUPS).map(x=>x.key); const d=await chrome.storage.local.get(keys); const writes={}; for(const [name,cfg] of Object.entries(SUBGROUPS)){const vals=listFromStored(d[cfg.key],cfg.defaults).slice(0,2); writes[cfg.key]=vals.join("\n"); renderSubgroup(name,vals);} await chrome.storage.local.set(writes); await syncCombinedDomainKeys(); }
async function syncSubgroupsFromGithub() {
  try {
    const res = await fetch(DOMAINS_LIST_URL + "?t=" + Date.now(), { cache: "no-store", credentials: "omit" });
    if (!res.ok) return false;
    const cfg = await res.json();
    const map = { ibetAgent: cfg.ibetAgentDomains, ibetMember: cfg.ibetMemberDomains, sbobetAgent: cfg.sbobetAgentDomains, sbobetMember: cfg.sbobetMemberDomains };
    const writes = {};
    for (const [name, vals] of Object.entries(map)) {
      if (!Array.isArray(vals) || !vals.length) return false;
      const normalized = uniqueNormalizedDomains(vals.join("\n")).slice(0, 2);
      if (!normalized.length) return false;
      writes[SUBGROUPS[name].key] = normalized.join("\n");
    }
    writes[STORAGE_KEYS.ibetDomainsText] = [writes[STORAGE_KEYS.ibetAgentDomains], writes[STORAGE_KEYS.ibetMemberDomains]].join("\n");
    writes[STORAGE_KEYS.sbobetDomainsText] = [writes[STORAGE_KEYS.sbobetAgentDomains], writes[STORAGE_KEYS.sbobetMemberDomains]].join("\n");
    writes.githubDomainsLastSync = Date.now();
    await chrome.storage.local.set(writes);
    return true;
  } catch { return false; }
}

async function loadState() {
  const data = await chrome.storage.local.get([
    STORAGE_KEYS.masterEnabled,
    STORAGE_KEYS.proxyLine,
    STORAGE_KEYS.proxyLine2,
    STORAGE_KEYS.ibetDomainsText,
    STORAGE_KEYS.sbobetDomainsText,
  ]);
  const master = data[STORAGE_KEYS.masterEnabled] !== false;
  setMasterUi(master);
  $("proxyLine").value = data[STORAGE_KEYS.proxyLine] || "";
  $("proxyLine2").value = data[STORAGE_KEYS.proxyLine2] || "";
  await syncSubgroupsFromGithub();
  await loadSubgroups();
  await chrome.runtime.sendMessage({type:"APPLY_PROXY"}).catch(() => {});
  takeFormBaseline();
  unsavedGuardEnabled = true;
}

async function saveAndApply() {
  hideMessage();
  const proxyLine = $("proxyLine").value;
  const proxyLine2 = $("proxyLine2").value;
  const activeSlot = "1";
  const domainsData = await chrome.storage.local.get([STORAGE_KEYS.ibetDomainsText, STORAGE_KEYS.sbobetDomainsText]);
  const ibetDomainsText = domainsData[STORAGE_KEYS.ibetDomainsText] || IBET_DOMAINS_TEXT;
  const sbobetDomainsText = domainsData[STORAGE_KEYS.sbobetDomainsText] || SBOBET_DOMAINS_TEXT;
  const masterEnabled = $("masterSwitch").classList.contains("on");

  if (masterEnabled) {
    try {
      parseProxyLine(proxyLine);
      if (proxyLine2.trim()) parseProxyLine(proxyLine2);
    } catch (e) {
      showMessage(e instanceof Error ? e.message : String(e), "err");
      return false;
    }
  }

  await chrome.storage.local.set({
    [STORAGE_KEYS.masterEnabled]: masterEnabled,
    [STORAGE_KEYS.proxyLine]: proxyLine.trim(),
    [STORAGE_KEYS.proxyLine2]: proxyLine2.trim(),
    [STORAGE_KEYS.activeProxySlot]: activeSlot,
    [STORAGE_KEYS.ibetDomainsText]: ibetDomainsText,
    [STORAGE_KEYS.sbobetDomainsText]: sbobetDomainsText,
  });

  try {
    const res = await chrome.runtime.sendMessage({ type: "APPLY_PROXY" });
    if (res && res.ok === false) {
      showMessage(res.error || "Không áp dụng được proxy.", "err");
      return false;
    }
    showMessage("ĐÃ LƯU PROXY IBET + SBOBET.", "ok");
    takeFormBaseline();
  } catch (e) {
    showMessage(e instanceof Error ? e.message : String(e), "err");
    return false;
  }

  chrome.runtime.sendMessage({ type: "REFRESH_ICON" }).catch(() => {});
  return true;
}

async function clearAll() {
  hideMessage();
  setMasterUi(false);
  $("proxyLine").value = "";
  $("proxyLine2").value = "";
  await chrome.storage.local.set({
    [STORAGE_KEYS.masterEnabled]: false,
    [STORAGE_KEYS.proxyLine]: "",
    [STORAGE_KEYS.proxyLine2]: "",
    [STORAGE_KEYS.ibetDomainsText]: IBET_DOMAINS_TEXT,
    [STORAGE_KEYS.sbobetDomainsText]: SBOBET_DOMAINS_TEXT,
  });
  const reset = {};
  for (const [name,cfg] of Object.entries(SUBGROUPS)) { reset[cfg.key] = cfg.defaults.join("\n"); renderSubgroup(name, cfg.defaults); }
  await chrome.storage.local.set(reset);
  await syncCombinedDomainKeys();
  try {
    const res = await chrome.runtime.sendMessage({ type: "APPLY_PROXY" });
    if (res && res.ok === false) {
      showMessage(res.error || "KHÔNG XÓA ĐƯỢC CẤU HÌNH PROXY.", "err");
      return;
    }
    showMessage("ĐÃ XÓA PROXY VÀ KHÔI PHỤC DANH SÁCH LINK MẶC ĐỊNH.", "ok");
    takeFormBaseline();
  } catch (e) {
    showMessage(e instanceof Error ? e.message : String(e), "err");
  }
  chrome.runtime.sendMessage({ type: "REFRESH_ICON" }).catch(() => {});
}

function toggleMaster() {
  const sw = $("masterSwitch");
  const on = !sw.classList.contains("on");
  setMasterUi(on);
  hideMessage();
  chrome.storage.local.set({ [STORAGE_KEYS.masterEnabled]: on }).then(() => {
    chrome.runtime.sendMessage({ type: "APPLY_PROXY" }).then((res) => {
      if (res && res.ok === false) {
        showMessage(res.error || "Lỗi áp dụng.", "err");
      }
      takeFormBaseline();
    });
    chrome.runtime.sendMessage({ type: "REFRESH_ICON" }).catch(() => {});
  });
}

/**
 * Chuẩn hoá từng dòng tải về (giống hướng xử lý background).
 * @param {string} raw
 * @returns {string[]}
 */
function parseFetchedDomainsRaw(raw) {
  const text = String(raw || "")
    .replace(/^\uFEFF/, "")
    .trim();
  const lines = text.split(/\r?\n/);
  const out = [];
  const seen = new Set();
  for (const line of lines) {
    const s = line.trim();
    if (!s || s.startsWith("#")) continue;
    const norm = normalizeDomainUserInput(s) || s;
    const key = norm.replace(/^\*\./, "").toLowerCase();
    if (!key || seen.has(key)) continue;
    seen.add(key);
    out.push(norm);
  }
  return out;
}

async function loadDomainsFromRemote() {
  const btn = $("btnFetchDomains");
  const label = btn.textContent;
  btn.disabled = true;
  btn.textContent = "Đang tải…";
  hideMessage();

  try {
    const res = await fetch(DOMAINS_LIST_URL, {
      cache: "no-store",
      credentials: "omit",
    });
    if (!res.ok) {
      throw new Error(`HTTP ${res.status}`);
    }
    const raw = await res.text();
    const domains = parseFetchedDomainsRaw(raw);
    if (!domains.length) {
      throw new Error("File không có domain hợp lệ.");
    }
    const domainsText = domains.join("\n");
    await chrome.storage.local.set({
      [STORAGE_KEYS.domainsText]: domainsText,
      [STORAGE_KEYS.domainsLockedFromFetch]: true,
    });
    renderRemoteDomainList(domainsText);
    updateDomainsLockUi(true);
    domainsLockedState = true;
    lockedDomainsSnapshot = domainsText;
    const saved = await saveAndApply();
    if (saved) {
      showMessage(`Đã tải ${domains.length} tên miền và tự động lưu áp dụng.`, "ok");
    }
  } catch (e) {
    const msg =
      e instanceof TypeError
        ? "Không tải được (mạng hoặc chặn CORS)."
        : e instanceof Error
          ? e.message
          : String(e);
    showMessage("Lỗi tải danh sách: " + msg, "err");
  } finally {
    btn.disabled = false;
    btn.textContent = label;
  }
}

document.addEventListener("DOMContentLoaded", () => {
  loadState().catch((e) => showMessage(String(e), "err"));
  chrome.runtime.sendMessage({ type: "REFRESH_ICON" }).catch(() => {});


  $("btnSave").addEventListener("click", () => saveAndApply().catch((e) => showMessage(String(e), "err")));
  $("btnClear").addEventListener("click", () => clearAll().catch((e) => showMessage(String(e), "err")));
  const addBtn=$("btnAddMenu"), addMenu=$("addMenu"), addInput=$("addDomainInput");
  const toggleAddMenu=()=>{
    if(!normalizeDomainUserInput(addInput.value)){ showMessage("HÃY NHẬP LINK TRƯỚC.","err"); addInput.focus(); return; }
    const open=!addMenu.classList.contains("open");
    addMenu.classList.toggle("open",open); addMenu.setAttribute("aria-hidden", open ? "false" : "true");
  };
  addBtn.addEventListener("click",toggleAddMenu);
  addInput.addEventListener("keydown",e=>{ if(e.key==="Enter"){e.preventDefault(); toggleAddMenu();} });
  addMenu.querySelectorAll("button[data-group]").forEach(btn=>btn.addEventListener("click",()=>{
    const group=btn.dataset.group;
    addMenu.classList.remove("open"); addMenu.setAttribute("aria-hidden","true");
    addSubgroup(group).catch(e=>showMessage(String(e),"err"));
  }));
  document.addEventListener("click",e=>{ if(!e.target.closest(".single-add-wrap")){addMenu.classList.remove("open"); addMenu.setAttribute("aria-hidden","true");} });

  const sw = $("masterSwitch");
  sw.addEventListener("click", toggleMaster);
  sw.addEventListener("keydown", (ev) => {
    if (ev.key === "Enter" || ev.key === " ") {
      ev.preventDefault();
      toggleMaster();
    }
  });

  window.addEventListener("beforeunload", (e) => {
    if (hasUnsavedChanges()) {
      e.preventDefault();
      e.returnValue =
        "Bạn có thay đổi chưa lưu. Nhấn Save & Apply hoặc hủy thay đổi trước khi đóng.";
    }
  });
});
