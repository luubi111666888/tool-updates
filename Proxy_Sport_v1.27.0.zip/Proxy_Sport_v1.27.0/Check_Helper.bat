@echo off
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { Invoke-RestMethod -UseBasicParsing http://127.0.0.1:19080/status -TimeoutSec 2 ^| ConvertTo-Json -Depth 4 } catch { Write-Host '[ERROR] Helper khong chay'; exit 1 }"
pause
