/**
 * PROXY SPORT v1.27.0
 * Clean engine based on the user's original build.
 *
 * Design:
 * - Chrome PAC only routes traffic; it does not repeatedly rewrite PAC for IP checks.
 * - Four isolated local proxy lanes: iBet Member, iBet Agent, SBOBET Member, SBOBET Agent.
 * - Agent/Member may share the same upstream Requyet endpoint, but never share the same
 *   local Chrome proxy socket pool. Closing one lane resets only that lane.
 * - When the last tab of a lane is closed/navigates away, the helper closes that
 *   lane's live sockets. The next open therefore creates new upstream connections.
 * - One IP-check request per completed listed page; no 50s cooldown and no IP cache.
 */

const STORAGE_KEYS = {
  masterEnabled: "masterEnabled",
  proxyLine: "proxyLine",
  proxyLine2: "proxyLine2",
  domainsText: "domainsText",
  ibetDomainsText: "ibetDomainsText",
  sbobetDomainsText: "sbobetDomainsText",
  ibetAgentDomains: "ibetAgentDomains",
  ibetMemberDomains: "ibetMemberDomains",
  sbobetAgentDomains: "sbobetAgentDomains",
  sbobetMemberDomains: "sbobetMemberDomains",
};

const DEFAULT_IBET_DOMAINS = [
  "*.14186vv.com",
  "*.025710.com",
  "*.nmcccc1.net",
  "*.litap88.com",
  "*.perpa88.com",
  "*.fika88.com",
];
const DEFAULT_SBOBET_DOMAINS = [
  "agent.namnamvang.com",
  "agent.sbobet.com",
  "agent.senangmelompat.com",
  "balimassagecenter.com",
  "sbobong.com",
  "sbobet.com",
];

const DEFAULT_SUBGROUP_DOMAINS = {
  ibetAgent: ["*.litap88.com", "*.fika88.com"],
  ibetMember: ["*.025710.com", "*.14186vv.com"],
  sbobetAgent: ["*.agent.namnamvang.com", "*.agent.senangmelompat.com"],
  sbobetMember: ["*.sbobong.com", "*.sbobet.com"],
};

const GITHUB_UPDATE_URL = "https://raw.githubusercontent.com/luubi111666888/tool-updates/main/proxy-sport-update.json";
const GITHUB_DOMAINS_URL = "https://raw.githubusercontent.com/luubi111666888/tool-updates/main/proxy-sport-domains.json";

const HELPER_CONTROL = "http://127.0.0.1:19080";
const REQUIRED_HELPER_VERSION = "1.27.0";
const HELPER_PORTS = {
  ibetMember: 19081,
  ibetAgent: 19082,
  sbobetMember: 19083,
  sbobetAgent: 19084,
};
const IP_CHECK_URLS = {
  ibetMember: "https://checkipv4.4lowin.cc",
  ibetAgent: "https://api.ipify.org",
  sbobetMember: "https://ipv4.icanhazip.com",
  sbobetAgent: "https://v4.ident.me",
};

let cachedSubgroups = {
  ibetAgent: [...DEFAULT_SUBGROUP_DOMAINS.ibetAgent],
  ibetMember: [...DEFAULT_SUBGROUP_DOMAINS.ibetMember],
  sbobetAgent: [...DEFAULT_SUBGROUP_DOMAINS.sbobetAgent],
  sbobetMember: [...DEFAULT_SUBGROUP_DOMAINS.sbobetMember],
};
let cachedDomainGroups = {
  ibet: [...cachedSubgroups.ibetAgent, ...cachedSubgroups.ibetMember],
  sbobet: [...cachedSubgroups.sbobetAgent, ...cachedSubgroups.sbobetMember],
};

function compareVersions(a, b) {
  const aa = String(a || "0").split(".").map((n) => parseInt(n, 10) || 0);
  const bb = String(b || "0").split(".").map((n) => parseInt(n, 10) || 0);
  const n = Math.max(aa.length, bb.length);
  for (let i = 0; i < n; i++) {
    const x = aa[i] || 0;
    const y = bb[i] || 0;
    if (x > y) return 1;
    if (x < y) return -1;
  }
  return 0;
}

async function checkGithubUpdate() {
  try {
    const res = await fetch(GITHUB_UPDATE_URL + "?t=" + Date.now(), {
      cache: "no-store",
      credentials: "omit",
    });
    if (!res.ok) throw new Error("HTTP " + res.status);
    const info = await res.json();
    const current = chrome.runtime.getManifest().version;
    const latest = String(info.version || "").trim();
    const available = !!latest && compareVersions(latest, current) > 0;
    await chrome.storage.local.set({
      proxySportCurrentVersion: current,
      proxySportLatestVersion: latest || current,
      proxySportUpdateAvailable: available,
      proxySportUpdateUrl: String(info.url || ""),
      proxySportUpdateLastCheck: Date.now(),
    });
    if (available) {
      await chrome.action.setBadgeText({ text: "UP" });
      await chrome.action.setBadgeBackgroundColor({ color: "#d93025" });
      await chrome.action.setTitle({ title: `PROXY SPORT - Co ban moi ${latest}` });
    } else {
      await chrome.action.setBadgeText({ text: "" });
    }
  } catch (e) {
    console.warn("Update check skipped:", e);
  }
}

function toAsciiHost(host) {
  const raw = String(host || "").trim().toLowerCase();
  if (!raw) return "";
  try {
    return new URL("http://" + raw).hostname;
  } catch {
    return raw;
  }
}

function normalizeRemoteDomainList(value) {
  if (!Array.isArray(value)) return [];
  const out = [];
  const seen = new Set();
  for (const item of value) {
    let v = String(item || "").trim().toLowerCase();
    if (!v) continue;
    v = v.replace(/^https?:\/\//, "").split("/")[0].replace(/^www\./, "");
    v = v.replace(/^\*\./, "");
    v = toAsciiHost(v);
    if (!v || seen.has(v)) continue;
    seen.add(v);
    out.push("*." + v);
  }
  return out.slice(0, 2);
}

async function syncDomainsFromGithub() {
  try {
    const res = await fetch(GITHUB_DOMAINS_URL + "?t=" + Date.now(), {
      cache: "no-store",
      credentials: "omit",
    });
    if (!res.ok) throw new Error("HTTP " + res.status);
    const cfg = await res.json();
    const ia = normalizeRemoteDomainList(cfg.ibetAgentDomains);
    const im = normalizeRemoteDomainList(cfg.ibetMemberDomains);
    const sa = normalizeRemoteDomainList(cfg.sbobetAgentDomains);
    const sm = normalizeRemoteDomainList(cfg.sbobetMemberDomains);
    if (!ia.length || !im.length || !sa.length || !sm.length) throw new Error("Invalid domain config");
    await chrome.storage.local.set({
      ibetAgentDomains: ia.join("\n"),
      ibetMemberDomains: im.join("\n"),
      sbobetAgentDomains: sa.join("\n"),
      sbobetMemberDomains: sm.join("\n"),
      ibetDomainsText: [...ia, ...im].join("\n"),
      sbobetDomainsText: [...sa, ...sm].join("\n"),
      githubDomainsLastSync: Date.now(),
    });
    return true;
  } catch (e) {
    console.warn("Domain sync skipped:", e);
    return false;
  }
}

function parseProxyLine(line) {
  const raw = String(line || "").trim();
  if (!raw) throw new Error("Proxy trong.");

  if (raw.includes("@")) {
    const at = raw.indexOf("@");
    const left = raw.slice(0, at).trim();
    const right = raw.slice(at + 1).trim();
    const colon = left.lastIndexOf(":");
    if (colon <= 0) throw new Error("Dinh dang host:port@user:pass khong hop le.");
    const host = toAsciiHost(left.slice(0, colon).trim());
    const port = left.slice(colon + 1).trim();
    const uc = right.indexOf(":");
    const user = uc >= 0 ? right.slice(0, uc) : right;
    const pass = uc >= 0 ? right.slice(uc + 1) : "";
    if (!host || !/^\d+$/.test(port) || Number(port) < 1 || Number(port) > 65535) {
      throw new Error("Host/port khong hop le.");
    }
    return { host, port: Number(port), user, pass };
  }

  const parts = raw.split(":");
  if (parts.length < 2) throw new Error("Can host:port hoac host:port:user:pass.");
  const host = toAsciiHost(parts[0]);
  const port = parts[1];
  const user = parts.length >= 3 ? parts[2] : "";
  const pass = parts.length >= 4 ? parts.slice(3).join(":") : "";
  if (!host || !/^\d+$/.test(port) || Number(port) < 1 || Number(port) > 65535) {
    throw new Error("Host/port khong hop le.");
  }
  return { host, port: Number(port), user, pass };
}

function normalizeDomainLine(line) {
  let s = String(line || "").trim().toLowerCase();
  if (!s || s.startsWith("#")) return null;
  s = s.replace(/^https?:\/\//, "").replace(/\/.*$/, "").replace(/:\d+$/, "");
  s = s.replace(/^\*\./, "");
  s = toAsciiHost(s);
  return s ? "*." + s : null;
}

function parseDomainsList(text) {
  const out = [];
  const seen = new Set();
  for (const line of String(text || "").split(/\r?\n/)) {
    const d = normalizeDomainLine(line);
    if (!d || seen.has(d)) continue;
    seen.add(d);
    out.push(d);
  }
  return out;
}

function hostMatchesProxyList(host, domains) {
  const h = String(host || "").toLowerCase();
  for (const d of domains || []) {
    const base = String(d).replace(/^\*\./, "").toLowerCase();
    if (h === base || h.endsWith("." + base)) return true;
  }
  return false;
}

function escapePacString(s) {
  return String(s).replace(/\\/g, "\\\\").replace(/"/g, '\\"');
}

function buildCondition(domains) {
  const rules = [];
  for (const d of domains) {
    const base = String(d).replace(/^\*\./, "").toLowerCase();
    if (!base) continue;
    rules.push(`(dnsDomainIs(host, "${escapePacString(base)}") || shExpMatch(host, "*.${escapePacString(base)}"))`);
  }
  return rules.length ? rules.join(" || ") : "false";
}

function buildPacScript(subgroups, ibetEnabled, sbobetEnabled) {
  const cond = {};
  for (const [name, domains] of Object.entries(subgroups)) cond[name] = buildCondition(domains);
  const route = {
    ibetMember: ibetEnabled ? `PROXY 127.0.0.1:${HELPER_PORTS.ibetMember}` : "DIRECT",
    ibetAgent: ibetEnabled ? `PROXY 127.0.0.1:${HELPER_PORTS.ibetAgent}` : "DIRECT",
    sbobetMember: sbobetEnabled ? `PROXY 127.0.0.1:${HELPER_PORTS.sbobetMember}` : "DIRECT",
    sbobetAgent: sbobetEnabled ? `PROXY 127.0.0.1:${HELPER_PORTS.sbobetAgent}` : "DIRECT",
  };
  const pac = `function FindProxyForURL(url, host) {
  if (isPlainHostName(host) || host === "localhost" || host === "127.0.0.1") return "DIRECT";
  if (dnsDomainIs(host, "checkipv4.4lowin.cc") || shExpMatch(host, "*.checkipv4.4lowin.cc")) return "${route.ibetMember}";
  if (dnsDomainIs(host, "api.ipify.org") || shExpMatch(host, "*.api.ipify.org")) return "${route.ibetAgent}";
  if (dnsDomainIs(host, "ipv4.icanhazip.com") || shExpMatch(host, "*.ipv4.icanhazip.com")) return "${route.sbobetMember}";
  if (dnsDomainIs(host, "v4.ident.me") || shExpMatch(host, "*.v4.ident.me")) return "${route.sbobetAgent}";
  if (${cond.ibetAgent}) return "${route.ibetAgent}";
  if (${cond.ibetMember}) return "${route.ibetMember}";
  if (${cond.sbobetAgent}) return "${route.sbobetAgent}";
  if (${cond.sbobetMember}) return "${route.sbobetMember}";
  return "DIRECT";
}`;
  for (let i = 0; i < pac.length; i++) {
    if (pac.charCodeAt(i) > 127) throw new Error("PAC contains non-ASCII data.");
  }
  return pac;
}

async function helperRequest(path, body, timeoutMs = 1800) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(HELPER_CONTROL + path, {
      method: body ? "POST" : "GET",
      headers: body ? { "Content-Type": "application/json" } : undefined,
      body: body ? JSON.stringify(body) : undefined,
      cache: "no-store",
      signal: ctrl.signal,
    });
    if (!res.ok) throw new Error("Helper HTTP " + res.status);
    const txt = await res.text();
    try { return JSON.parse(txt); } catch { return { ok: true, text: txt }; }
  } finally {
    clearTimeout(timer);
  }
}

async function configureHelper(group, proxy) {
  return helperRequest("/config", {
    group,
    enabled: !!proxy,
    host: proxy?.host || "",
    port: proxy?.port || 0,
    user: proxy?.user || "",
    pass: proxy?.pass || "",
  });
}

async function resetHelperGroup(group) {
  try {
    await helperRequest("/reset", { group }, 1200);
  } catch (e) {
    console.warn("Helper reset failed:", group, e);
  }
}

async function getHelperStatus() {
  try {
    const r = await helperRequest("/status", null, 900);
    return r && r.ok !== false ? r : null;
  } catch {
    return null;
  }
}

async function requestHelperUpdateCheck() {
  try {
    await helperRequest("/update-check", {}, 1200);
  } catch {
    // Older helper versions may not have this endpoint.
  }
}

async function loadDomainGroupsFromStorage() {
  const data = await chrome.storage.local.get([
    STORAGE_KEYS.ibetAgentDomains,
    STORAGE_KEYS.ibetMemberDomains,
    STORAGE_KEYS.sbobetAgentDomains,
    STORAGE_KEYS.sbobetMemberDomains,
  ]);
  cachedSubgroups = {
    ibetAgent: parseDomainsList(data[STORAGE_KEYS.ibetAgentDomains] || DEFAULT_SUBGROUP_DOMAINS.ibetAgent.join("\n")),
    ibetMember: parseDomainsList(data[STORAGE_KEYS.ibetMemberDomains] || DEFAULT_SUBGROUP_DOMAINS.ibetMember.join("\n")),
    sbobetAgent: parseDomainsList(data[STORAGE_KEYS.sbobetAgentDomains] || DEFAULT_SUBGROUP_DOMAINS.sbobetAgent.join("\n")),
    sbobetMember: parseDomainsList(data[STORAGE_KEYS.sbobetMemberDomains] || DEFAULT_SUBGROUP_DOMAINS.sbobetMember.join("\n")),
  };
  cachedDomainGroups = {
    ibet: [...cachedSubgroups.ibetAgent, ...cachedSubgroups.ibetMember],
    sbobet: [...cachedSubgroups.sbobetAgent, ...cachedSubgroups.sbobetMember],
  };
}

async function applyProxySettings() {
  const data = await chrome.storage.local.get([
    STORAGE_KEYS.masterEnabled,
    STORAGE_KEYS.proxyLine,
    STORAGE_KEYS.proxyLine2,
    STORAGE_KEYS.ibetDomainsText,
    STORAGE_KEYS.sbobetDomainsText,
    STORAGE_KEYS.ibetAgentDomains,
    STORAGE_KEYS.ibetMemberDomains,
    STORAGE_KEYS.sbobetAgentDomains,
    STORAGE_KEYS.sbobetMemberDomains,
  ]);

  cachedSubgroups = {
    ibetAgent: parseDomainsList(data[STORAGE_KEYS.ibetAgentDomains] || DEFAULT_SUBGROUP_DOMAINS.ibetAgent.join("\n")),
    ibetMember: parseDomainsList(data[STORAGE_KEYS.ibetMemberDomains] || DEFAULT_SUBGROUP_DOMAINS.ibetMember.join("\n")),
    sbobetAgent: parseDomainsList(data[STORAGE_KEYS.sbobetAgentDomains] || DEFAULT_SUBGROUP_DOMAINS.sbobetAgent.join("\n")),
    sbobetMember: parseDomainsList(data[STORAGE_KEYS.sbobetMemberDomains] || DEFAULT_SUBGROUP_DOMAINS.sbobetMember.join("\n")),
  };
  cachedDomainGroups = {
    ibet: [...cachedSubgroups.ibetAgent, ...cachedSubgroups.ibetMember],
    sbobet: [...cachedSubgroups.sbobetAgent, ...cachedSubgroups.sbobetMember],
  };

  if (data[STORAGE_KEYS.masterEnabled] === false) {
    await chrome.proxy.settings.clear({ scope: "regular" });
    await Promise.allSettled([
      configureHelper("ibet", null),
      configureHelper("sbobet", null),
      resetHelperGroup("ibetMember"),
      resetHelperGroup("ibetAgent"),
      resetHelperGroup("sbobetMember"),
      resetHelperGroup("sbobetAgent"),
    ]);
    return { ok: true, mode: "off" };
  }

  let ibet;
  try {
    ibet = parseProxyLine(String(data[STORAGE_KEYS.proxyLine] || ""));
  } catch (e) {
    await chrome.proxy.settings.clear({ scope: "regular" });
    return { ok: false, error: "Proxy iBet: " + (e instanceof Error ? e.message : String(e)) };
  }

  let sbobet = null;
  const sbobetRaw = String(data[STORAGE_KEYS.proxyLine2] || "").trim();
  if (sbobetRaw) {
    try {
      sbobet = parseProxyLine(sbobetRaw);
    } catch (e) {
      return { ok: false, error: "Proxy SBOBET: " + (e instanceof Error ? e.message : String(e)) };
    }
  }

  const helperStatus = await getHelperStatus();
  if (!helperStatus) {
    await chrome.proxy.settings.clear({ scope: "regular" });
    return { ok: false, error: "Proxy Helper chua chay. Hay chay SETUP_1_LAN.bat 1 lan." };
  }
  const helperVersion = String(helperStatus.version || "0");
  if (compareVersions(helperVersion, REQUIRED_HELPER_VERSION) < 0) {
    await chrome.proxy.settings.clear({ scope: "regular" });
    return { ok: false, error: `Proxy Helper ${helperVersion} qua cu. Hay chay SETUP_1_LAN.bat 1 lan de bat tu cap nhat.` };
  }

  try {
    await configureHelper("ibet", ibet);
    await configureHelper("sbobet", sbobet);
    requestHelperUpdateCheck().catch(() => {});
  } catch (e) {
    await chrome.proxy.settings.clear({ scope: "regular" });
    return { ok: false, error: "Khong cau hinh duoc Proxy Helper: " + String(e) };
  }

  const pac = buildPacScript(cachedSubgroups, true, !!sbobet);
  await chrome.proxy.settings.set({
    value: { mode: "pac_script", pacScript: { data: pac } },
    scope: "regular",
  });
  return {
    ok: true,
    mode: "helper",
    ibetDomains: cachedDomainGroups.ibet.length,
    sbobetDomains: cachedDomainGroups.sbobet.length,
  };
}

function extractPublicIp(text) {
  const s = String(text || "").trim();
  const m = s.match(/\b(\d{1,3}(?:\.\d{1,3}){3})\b/);
  return m ? m[1] : (s.split(/\r?\n/)[0].trim() || "-");
}

async function fetchGroupIp(group) {
  const url = IP_CHECK_URLS[group];
  const sep = url.includes("?") ? "&" : "?";
  const r = await fetch(url + sep + "t=" + Date.now(), {
    cache: "no-store",
    credentials: "omit",
  });
  if (!r.ok) throw new Error(String(r.status));
  return extractPublicIp(await r.text());
}

async function getHostForTab(tab) {
  if (!tab?.url) return "";
  try {
    const u = new URL(tab.url);
    return (u.protocol === "http:" || u.protocol === "https:") ? (u.hostname || "") : "";
  } catch {
    return "";
  }
}

function groupForHost(host) {
  if (hostMatchesProxyList(host, cachedSubgroups.ibetAgent)) return "ibetAgent";
  if (hostMatchesProxyList(host, cachedSubgroups.ibetMember)) return "ibetMember";
  if (hostMatchesProxyList(host, cachedSubgroups.sbobetAgent)) return "sbobetAgent";
  if (hostMatchesProxyList(host, cachedSubgroups.sbobetMember)) return "sbobetMember";
  return "";
}

function systemForGroup(group) {
  return String(group || "").startsWith("ibet") ? "ibet" : String(group || "").startsWith("sbobet") ? "sbobet" : "";
}

function labelForGroup(group) {
  return ({
    ibetMember: "IBET",
    ibetAgent: "AGENT IBET",
    sbobetMember: "SBOBET",
    sbobetAgent: "AGENT SBOBET",
  })[group] || String(group || "").toUpperCase();
}

async function updateIconForTab(tabId) {
  let tab;
  try {
    tab = tabId != null ? await chrome.tabs.get(tabId) : (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
  } catch {
    tab = undefined;
  }
  const data = await chrome.storage.local.get([STORAGE_KEYS.masterEnabled, STORAGE_KEYS.proxyLine, STORAGE_KEYS.proxyLine2]);
  if (!tab || data[STORAGE_KEYS.masterEnabled] === false) {
    await chrome.action.setTitle({ title: "PROXY SPORT" });
    return;
  }
  const host = await getHostForTab(tab);
  const group = groupForHost(host);
  if (!group) {
    await chrome.action.setTitle({ tabId: tab.id, title: "PROXY SPORT" }).catch(() => {});
    return;
  }
  const system = systemForGroup(group);
  const configured = system === "ibet" ? !!String(data[STORAGE_KEYS.proxyLine] || "").trim() : !!String(data[STORAGE_KEYS.proxyLine2] || "").trim();
  const label = labelForGroup(group);
  await chrome.action.setTitle({
    tabId: tab.id,
    title: configured ? `PROXY ${label} DANG BAT` : `PROXY ${label} CHUA CAU HINH`,
  }).catch(() => {});
}

async function injectIpToast(tabId, ip, group) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      func: (ipParam, groupParam) => {
        const id = "proxy-sport-ip-toast";
        document.getElementById(id)?.remove();
        const wrap = document.createElement("div");
        wrap.id = id;
        wrap.setAttribute("role", "status");
        wrap.style.cssText = [
          "position:fixed", "top:12px", "right:12px", "z-index:2147483647",
          "pointer-events:none", "margin:0", "padding:0", "width:max-content",
          "max-width:min(90vw,340px)", "height:auto", "background:transparent"
        ].join(";");
        const el = document.createElement("div");
        el.style.cssText = [
          "margin:0", "padding:10px 14px", "border-radius:8px",
          "font:13px/1.35 system-ui,Segoe UI,sans-serif", "background:rgba(15,23,42,.94)",
          "color:#e0f2fe", "border:1px solid rgba(34,211,238,.5)",
          "box-shadow:0 6px 24px rgba(0,0,0,.4)", "word-break:break-word"
        ].join(";");
        const label = ({ ibetMember: "IBET", ibetAgent: "AGENT IBET", sbobetMember: "SBOBET", sbobetAgent: "AGENT SBOBET" })[groupParam] || String(groupParam || "").toUpperCase();
        el.textContent = label + " • PROXY ACTIVE • IP: " + ipParam;
        wrap.appendChild(el);
        (document.body || document.documentElement).appendChild(wrap);
        setTimeout(() => {
          wrap.style.transition = "opacity .45s ease";
          wrap.style.opacity = "0";
          setTimeout(() => wrap.remove(), 480);
        }, 12000);
      },
      args: [ip, group],
    });
  } catch {
    // Special pages cannot be injected.
  }
}

async function notifyIpWhenListedPageLoaded(tabId, tab) {
  if (!tab?.url) return;
  const data = await chrome.storage.local.get([
    STORAGE_KEYS.masterEnabled,
    STORAGE_KEYS.proxyLine,
    STORAGE_KEYS.proxyLine2,
  ]);
  if (data[STORAGE_KEYS.masterEnabled] === false) return;
  const host = await getHostForTab(tab);
  const group = groupForHost(host);
  if (!group) return;
  const system = systemForGroup(group);
  const line = system === "ibet" ? data[STORAGE_KEYS.proxyLine] : data[STORAGE_KEYS.proxyLine2];
  if (!String(line || "").trim()) return;

  try {
    const ip = await fetchGroupIp(group);
    await injectIpToast(tabId, ip, group);
    await chrome.action.setTitle({ tabId, title: `IP Connect: ${ip}` }).catch(() => {});
  } catch (e) {
    console.warn("IP check failed:", group, e);
  }
}

const SESSION_TAB_GROUPS_KEY = "proxySportTabGroups";

async function readTabGroupMap() {
  const r = await chrome.storage.session.get(SESSION_TAB_GROUPS_KEY);
  const v = r[SESSION_TAB_GROUPS_KEY];
  return v && typeof v === "object" ? v : {};
}

async function writeTabGroup(tabId, group) {
  const map = await readTabGroupMap();
  if (group) map[String(tabId)] = group;
  else delete map[String(tabId)];
  await chrome.storage.session.set({ [SESSION_TAB_GROUPS_KEY]: map });
}

async function groupHasOpenTabs(group, excludeTabId = null) {
  const tabs = await chrome.tabs.query({});
  for (const tab of tabs) {
    if (excludeTabId != null && tab.id === excludeTabId) continue;
    const host = await getHostForTab(tab);
    if (groupForHost(host) === group) return true;
  }
  return false;
}

async function resetIfGroupNoLongerOpen(group, excludeTabId = null) {
  if (!group) return;
  if (!(await groupHasOpenTabs(group, excludeTabId))) {
    await resetHelperGroup(group);
  }
}

async function reconcileTabGroupMap() {
  const tabs = await chrome.tabs.query({});
  const map = {};
  for (const tab of tabs) {
    if (tab.id == null) continue;
    const host = await getHostForTab(tab);
    const group = groupForHost(host);
    if (group) map[String(tab.id)] = group;
  }
  await chrome.storage.session.set({ [SESSION_TAB_GROUPS_KEY]: map });
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(STORAGE_KEYS.masterEnabled, (r) => {
    if (r[STORAGE_KEYS.masterEnabled] === undefined) {
      chrome.storage.local.set({
        [STORAGE_KEYS.masterEnabled]: true,
        [STORAGE_KEYS.ibetDomainsText]: DEFAULT_IBET_DOMAINS.join("\n"),
        [STORAGE_KEYS.sbobetDomainsText]: DEFAULT_SBOBET_DOMAINS.join("\n"),
        [STORAGE_KEYS.ibetAgentDomains]: DEFAULT_SUBGROUP_DOMAINS.ibetAgent.join("\n"),
        [STORAGE_KEYS.ibetMemberDomains]: DEFAULT_SUBGROUP_DOMAINS.ibetMember.join("\n"),
        [STORAGE_KEYS.sbobetAgentDomains]: DEFAULT_SUBGROUP_DOMAINS.sbobetAgent.join("\n"),
        [STORAGE_KEYS.sbobetMemberDomains]: DEFAULT_SUBGROUP_DOMAINS.sbobetMember.join("\n"),
      });
    }
  });
  checkGithubUpdate().catch(() => {});
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (
    changes[STORAGE_KEYS.masterEnabled] ||
    changes[STORAGE_KEYS.proxyLine] ||
    changes[STORAGE_KEYS.proxyLine2] ||
    changes[STORAGE_KEYS.domainsText] ||
    changes[STORAGE_KEYS.ibetDomainsText] ||
    changes[STORAGE_KEYS.sbobetDomainsText] ||
    changes[STORAGE_KEYS.ibetAgentDomains] ||
    changes[STORAGE_KEYS.ibetMemberDomains] ||
    changes[STORAGE_KEYS.sbobetAgentDomains] ||
    changes[STORAGE_KEYS.sbobetMemberDomains]
  ) {
    applyProxySettings().catch(() => {}).finally(() => updateIconForTab().catch(() => {}));
  }
});

chrome.tabs.onActivated.addListener((activeInfo) => {
  updateIconForTab(activeInfo.tabId).catch(() => {});
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  (async () => {
    if (changeInfo.url || changeInfo.status === "loading") {
      const map = await readTabGroupMap();
      const prev = map[String(tabId)] || "";
      const host = await getHostForTab(tab);
      const next = groupForHost(host);
      if (prev !== next) {
        await writeTabGroup(tabId, next);
        if (prev) await resetIfGroupNoLongerOpen(prev, tabId);
      }
    }
    if (changeInfo.status === "complete" && tab?.url) {
      await notifyIpWhenListedPageLoaded(tabId, tab);
      await updateIconForTab(tabId);
    }
  })().catch(() => {});
});

chrome.tabs.onRemoved.addListener((tabId) => {
  (async () => {
    const map = await readTabGroupMap();
    const group = map[String(tabId)] || "";
    delete map[String(tabId)];
    await chrome.storage.session.set({ [SESSION_TAB_GROUPS_KEY]: map });
    if (group) await resetIfGroupNoLongerOpen(group, tabId);
  })().catch(() => {});
});

chrome.windows.onFocusChanged.addListener((windowId) => {
  if (windowId !== chrome.windows.WINDOW_ID_NONE) updateIconForTab().catch(() => {});
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === "APPLY_PROXY") {
    applyProxySettings()
      .then((r) => sendResponse(r))
      .catch((e) => sendResponse({ ok: false, error: e instanceof Error ? e.message : String(e) }));
    return true;
  }
  if (msg?.type === "REFRESH_ICON") {
    updateIconForTab(msg.tabId)
      .then(() => sendResponse({ ok: true }))
      .catch((e) => sendResponse({ ok: false, error: String(e) }));
    return true;
  }
  return undefined;
});

// Startup: keep the original GitHub sync behavior, then apply once.
checkGithubUpdate().catch(() => {});
setInterval(() => checkGithubUpdate().catch(() => {}), 60 * 60 * 1000);

syncDomainsFromGithub()
  .catch(() => false)
  .finally(async () => {
    await loadDomainGroupsFromStorage().catch(() => {});
    await applyProxySettings().catch(() => {});
    await reconcileTabGroupMap().catch(() => {});
    await updateIconForTab().catch(() => {});
  });
