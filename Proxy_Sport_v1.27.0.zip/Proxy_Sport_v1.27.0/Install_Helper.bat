@echo off
call "%~dp0SETUP_1_LAN.bat"
