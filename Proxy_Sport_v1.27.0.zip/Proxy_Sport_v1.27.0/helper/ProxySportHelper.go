package main

import (
	"bufio"
	"context"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"os/signal"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"
)

const helperVersion = "1.27.0"
const helperUpdateManifestURL = "https://raw.githubusercontent.com/luubi111666888/tool-updates/main/proxy-sport-helper.json"

type HelperUpdateManifest struct {
	Version string `json:"version"`
	URL     string `json:"url"`
	SHA256  string `json:"sha256"`
}

type PersistedConfig struct {
	IBet   ProxyConfig `json:"ibet"`
	SBOBET ProxyConfig `json:"sbobet"`
}

type UpdateState struct {
	InProgress bool   `json:"inProgress"`
	Latest     string `json:"latest"`
	Pending    bool   `json:"pending"`
	LastError  string `json:"lastError"`
	LastCheck  string `json:"lastCheck"`
}

var updateStateMu sync.RWMutex
var updateState UpdateState

type ProxyConfig struct {
	Enabled bool   `json:"enabled"`
	Host    string `json:"host"`
	Port    int    `json:"port"`
	User    string `json:"user"`
	Pass    string `json:"pass"`
}

type ConfigRequest struct {
	Group   string `json:"group"`
	Enabled bool   `json:"enabled"`
	Host    string `json:"host"`
	Port    int    `json:"port"`
	User    string `json:"user"`
	Pass    string `json:"pass"`
}

type ResetRequest struct {
	Group string `json:"group"`
}

type GroupState struct {
	name  string
	mu    sync.RWMutex
	cfg   ProxyConfig
	conns map[net.Conn]struct{}
}

func NewGroupState(name string) *GroupState {
	return &GroupState{name: name, conns: make(map[net.Conn]struct{})}
}

func (g *GroupState) setConfig(c ProxyConfig) {
	g.mu.Lock()
	changed := g.cfg != c
	g.cfg = c
	g.mu.Unlock()
	if changed {
		g.resetConnections()
	}
}

func (g *GroupState) getConfig() ProxyConfig {
	g.mu.RLock()
	defer g.mu.RUnlock()
	return g.cfg
}

func (g *GroupState) addConn(c net.Conn) {
	g.mu.Lock()
	g.conns[c] = struct{}{}
	g.mu.Unlock()
}

func (g *GroupState) delConn(c net.Conn) {
	g.mu.Lock()
	delete(g.conns, c)
	g.mu.Unlock()
}

func (g *GroupState) resetConnections() int {
	g.mu.Lock()
	list := make([]net.Conn, 0, len(g.conns))
	for c := range g.conns {
		list = append(list, c)
	}
	g.mu.Unlock()
	for _, c := range list {
		_ = c.Close()
	}
	return len(list)
}

func (g *GroupState) connCount() int {
	g.mu.RLock()
	defer g.mu.RUnlock()
	return len(g.conns)
}

type trackedConn struct {
	net.Conn
	group *GroupState
	once  sync.Once
}

func (c *trackedConn) Close() error {
	var err error
	c.once.Do(func() {
		c.group.delConn(c)
		err = c.Conn.Close()
	})
	return err
}

type trackingListener struct {
	net.Listener
	group *GroupState
}

func (l *trackingListener) Accept() (net.Conn, error) {
	c, err := l.Listener.Accept()
	if err != nil {
		return nil, err
	}
	tc := &trackedConn{Conn: c, group: l.group}
	l.group.addConn(tc)
	return tc, nil
}

func upstreamAddr(c ProxyConfig) (string, error) {
	if !c.Enabled || strings.TrimSpace(c.Host) == "" || c.Port < 1 || c.Port > 65535 {
		return "", errors.New("proxy group is not configured")
	}
	return net.JoinHostPort(c.Host, strconv.Itoa(c.Port)), nil
}

func proxyAuthHeader(c ProxyConfig) string {
	if c.User == "" && c.Pass == "" {
		return ""
	}
	token := base64.StdEncoding.EncodeToString([]byte(c.User + ":" + c.Pass))
	return "Basic " + token
}

func dialUpstream(c ProxyConfig) (net.Conn, error) {
	addr, err := upstreamAddr(c)
	if err != nil {
		return nil, err
	}
	d := net.Dialer{Timeout: 12 * time.Second, KeepAlive: 30 * time.Second}
	return d.Dial("tcp", addr)
}

func tunnelCONNECT(w http.ResponseWriter, r *http.Request, g *GroupState) {
	hj, ok := w.(http.Hijacker)
	if !ok {
		http.Error(w, "hijack unsupported", http.StatusInternalServerError)
		return
	}
	client, rw, err := hj.Hijack()
	if err != nil {
		return
	}
	defer client.Close()

	cfg := g.getConfig()
	upstream, err := dialUpstream(cfg)
	if err != nil {
		_, _ = io.WriteString(client, "HTTP/1.1 502 Bad Gateway\r\nConnection: close\r\n\r\n")
		return
	}
	defer upstream.Close()

	target := r.Host
	if target == "" {
		target = r.URL.Host
	}
	if target == "" {
		_, _ = io.WriteString(client, "HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n")
		return
	}

	var b strings.Builder
	b.WriteString("CONNECT ")
	b.WriteString(target)
	b.WriteString(" HTTP/1.1\r\nHost: ")
	b.WriteString(target)
	b.WriteString("\r\nProxy-Connection: Keep-Alive\r\n")
	if ah := proxyAuthHeader(cfg); ah != "" {
		b.WriteString("Proxy-Authorization: ")
		b.WriteString(ah)
		b.WriteString("\r\n")
	}
	b.WriteString("\r\n")
	if _, err = io.WriteString(upstream, b.String()); err != nil {
		return
	}

	ubr := bufio.NewReader(upstream)
	// CONNECT 2xx switches the connection into a raw tunnel. Do not use
	// http.ReadResponse/resp.Body here because closing the response body can
	// close the tunnel itself. Forward the proxy response headers verbatim.
	var header strings.Builder
	statusCode := 0
	for i := 0; i < 200; i++ {
		line, readErr := ubr.ReadString('\n')
		if readErr != nil {
			_, _ = io.WriteString(client, "HTTP/1.1 502 Bad Gateway\r\nConnection: close\r\n\r\n")
			return
		}
		header.WriteString(line)
		if i == 0 {
			fields := strings.Fields(line)
			if len(fields) >= 2 {
				statusCode, _ = strconv.Atoi(fields[1])
			}
		}
		if line == "\r\n" || line == "\n" {
			break
		}
	}
	if _, err = io.WriteString(client, header.String()); err != nil {
		return
	}
	if statusCode < 200 || statusCode >= 300 {
		return
	}

	// Any bytes Chrome already queued after CONNECT must not be lost.
	if rw.Reader.Buffered() > 0 {
		n := rw.Reader.Buffered()
		_, _ = io.CopyN(upstream, rw.Reader, int64(n))
	}
	if ubr.Buffered() > 0 {
		n := ubr.Buffered()
		_, _ = io.CopyN(client, ubr, int64(n))
	}

	done := make(chan struct{}, 2)
	go func() {
		_, _ = io.Copy(upstream, client)
		if tc, ok := upstream.(*net.TCPConn); ok {
			_ = tc.CloseWrite()
		}
		done <- struct{}{}
	}()
	go func() {
		_, _ = io.Copy(client, upstream)
		if tc, ok := client.(*net.TCPConn); ok {
			_ = tc.CloseWrite()
		}
		done <- struct{}{}
	}()
	<-done
}

func forwardHTTP(w http.ResponseWriter, r *http.Request, g *GroupState) {
	cfg := g.getConfig()
	addr, err := upstreamAddr(cfg)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadGateway)
		return
	}
	proxyURL := &url.URL{Scheme: "http", Host: addr}
	if cfg.User != "" || cfg.Pass != "" {
		proxyURL.User = url.UserPassword(cfg.User, cfg.Pass)
	}
	tr := &http.Transport{
		Proxy:                 http.ProxyURL(proxyURL),
		DisableKeepAlives:     true,
		ForceAttemptHTTP2:     false,
		DialContext:           (&net.Dialer{Timeout: 12 * time.Second, KeepAlive: 30 * time.Second}).DialContext,
		TLSHandshakeTimeout:   12 * time.Second,
		ResponseHeaderTimeout: 30 * time.Second,
	}
	defer tr.CloseIdleConnections()

	out := r.Clone(r.Context())
	out.RequestURI = ""
	out.Header = r.Header.Clone()
	out.Header.Del("Proxy-Authorization")
	out.Header.Del("Proxy-Connection")
	out.Header.Set("Connection", "close")
	if out.URL.Scheme == "" {
		out.URL.Scheme = "http"
	}
	if out.URL.Host == "" {
		out.URL.Host = r.Host
	}

	resp, err := tr.RoundTrip(out)
	if err != nil {
		http.Error(w, "upstream proxy error: "+err.Error(), http.StatusBadGateway)
		return
	}
	defer resp.Body.Close()
	for k, vals := range resp.Header {
		for _, v := range vals {
			w.Header().Add(k, v)
		}
	}
	w.Header().Set("Connection", "close")
	w.WriteHeader(resp.StatusCode)
	_, _ = io.Copy(w, resp.Body)
}

func proxyHandler(g *GroupState) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		cfg := g.getConfig()
		if !cfg.Enabled {
			http.Error(w, "proxy group not configured", http.StatusBadGateway)
			return
		}
		if strings.EqualFold(r.Method, http.MethodConnect) {
			tunnelCONNECT(w, r, g)
			return
		}
		forwardHTTP(w, r, g)
	})
}

func runProxyServer(addr string, g *GroupState) error {
	ln, err := net.Listen("tcp", addr)
	if err != nil {
		return err
	}
	tl := &trackingListener{Listener: ln, group: g}
	srv := &http.Server{
		Handler:           proxyHandler(g),
		ReadHeaderTimeout: 20 * time.Second,
		IdleTimeout:       2 * time.Minute,
	}
	log.Printf("%s listener on %s", g.name, addr)
	return srv.Serve(tl)
}

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type")
	w.Header().Set("Access-Control-Allow-Methods", "GET,POST,OPTIONS")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}

func compareVersions(a, b string) int {
	split := func(v string) []int {
		parts := strings.Split(strings.TrimSpace(v), ".")
		out := make([]int, len(parts))
		for i, p := range parts {
			out[i], _ = strconv.Atoi(p)
		}
		return out
	}
	aa, bb := split(a), split(b)
	n := len(aa)
	if len(bb) > n {
		n = len(bb)
	}
	for i := 0; i < n; i++ {
		x, y := 0, 0
		if i < len(aa) {
			x = aa[i]
		}
		if i < len(bb) {
			y = bb[i]
		}
		if x > y {
			return 1
		}
		if x < y {
			return -1
		}
	}
	return 0
}

func helperDir() string {
	exe, err := os.Executable()
	if err != nil {
		return "."
	}
	return filepath.Dir(exe)
}

func configPath() string {
	return filepath.Join(helperDir(), "config.json")
}

func savePersistedConfig(ibetMember, sbobetMember *GroupState) error {
	// Persist one config per system. Agent/member use the same upstream proxy
	// but separate local listeners/connections.
	cfg := PersistedConfig{IBet: ibetMember.getConfig(), SBOBET: sbobetMember.getConfig()}
	b, err := json.MarshalIndent(cfg, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(configPath(), b, 0600)
}

func loadPersistedConfig(ibetMember, ibetAgent, sbobetMember, sbobetAgent *GroupState) {
	b, err := os.ReadFile(configPath())
	if err != nil {
		return
	}
	var cfg PersistedConfig
	if json.Unmarshal(b, &cfg) != nil {
		return
	}
	ibetMember.setConfig(cfg.IBet)
	ibetAgent.setConfig(cfg.IBet)
	sbobetMember.setConfig(cfg.SBOBET)
	sbobetAgent.setConfig(cfg.SBOBET)
}

func getUpdateState() UpdateState {
	updateStateMu.RLock()
	defer updateStateMu.RUnlock()
	return updateState
}

func setUpdateState(fn func(*UpdateState)) {
	updateStateMu.Lock()
	fn(&updateState)
	updateStateMu.Unlock()
}

func fetchUpdateManifest() (HelperUpdateManifest, error) {
	var out HelperUpdateManifest
	client := &http.Client{Timeout: 20 * time.Second}
	req, err := http.NewRequest(http.MethodGet, helperUpdateManifestURL+"?t="+strconv.FormatInt(time.Now().Unix(), 10), nil)
	if err != nil {
		return out, err
	}
	req.Header.Set("User-Agent", "ProxySportHelper/"+helperVersion)
	req.Header.Set("Cache-Control", "no-cache")
	resp, err := client.Do(req)
	if err != nil {
		return out, err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return out, fmt.Errorf("manifest HTTP %d", resp.StatusCode)
	}
	if err := json.NewDecoder(io.LimitReader(resp.Body, 128<<10)).Decode(&out); err != nil {
		return out, err
	}
	out.Version = strings.TrimSpace(out.Version)
	out.URL = strings.TrimSpace(out.URL)
	out.SHA256 = strings.ToLower(strings.TrimSpace(out.SHA256))
	if out.Version == "" || out.URL == "" || !strings.HasPrefix(strings.ToLower(out.URL), "https://") {
		return out, errors.New("invalid helper update manifest")
	}
	return out, nil
}

func downloadUpdateFile(m HelperUpdateManifest) (string, error) {
	client := &http.Client{Timeout: 60 * time.Second}
	req, err := http.NewRequest(http.MethodGet, m.URL+func() string {
		if strings.Contains(m.URL, "?") {
			return "&"
		}
		return "?"
	}()+"t="+strconv.FormatInt(time.Now().Unix(), 10), nil)
	if err != nil {
		return "", err
	}
	req.Header.Set("User-Agent", "ProxySportHelper/"+helperVersion)
	req.Header.Set("Cache-Control", "no-cache")
	resp, err := client.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return "", fmt.Errorf("helper HTTP %d", resp.StatusCode)
	}
	dst := filepath.Join(helperDir(), "ProxySportHelper.new.exe")
	f, err := os.Create(dst)
	if err != nil {
		return "", err
	}
	h := sha256.New()
	_, copyErr := io.Copy(io.MultiWriter(f, h), io.LimitReader(resp.Body, 64<<20))
	closeErr := f.Close()
	if copyErr != nil {
		_ = os.Remove(dst)
		return "", copyErr
	}
	if closeErr != nil {
		_ = os.Remove(dst)
		return "", closeErr
	}
	got := hex.EncodeToString(h.Sum(nil))
	if m.SHA256 != "" && !strings.EqualFold(got, m.SHA256) {
		_ = os.Remove(dst)
		return "", fmt.Errorf("sha256 mismatch: got %s", got)
	}
	return dst, nil
}

func scheduleSelfReplace(newExe string) error {
	oldExe, err := os.Executable()
	if err != nil {
		return err
	}
	script := filepath.Join(helperDir(), "ProxySportHelper_Update.cmd")
	content := "@echo off\r\n" +
		"setlocal\r\n" +
		"set \"OLD=" + oldExe + "\"\r\n" +
		"set \"NEW=" + newExe + "\"\r\n" +
		"for /L %%I in (1,1,30) do (\r\n" +
		"  move /Y \"%NEW%\" \"%OLD%\" >nul 2>&1\r\n" +
		"  if not errorlevel 1 goto restart\r\n" +
		"  ping 127.0.0.1 -n 2 >nul\r\n" +
		")\r\n" +
		"exit /b 1\r\n" +
		":restart\r\n" +
		"start \"\" \"%OLD%\"\r\n" +
		"del \"%~f0\"\r\n"
	if err := os.WriteFile(script, []byte(content), 0600); err != nil {
		return err
	}
	cmd := exec.Command("cmd.exe", "/C", script)
	cmd.Dir = helperDir()
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}
	if err := cmd.Start(); err != nil {
		return err
	}
	go func() {
		time.Sleep(500 * time.Millisecond)
		os.Exit(0)
	}()
	return nil
}

func checkForHelperUpdate(groups ...*GroupState) {
	updateStateMu.Lock()
	if updateState.InProgress {
		updateStateMu.Unlock()
		return
	}
	updateState.InProgress = true
	updateState.LastError = ""
	updateStateMu.Unlock()

	defer setUpdateState(func(s *UpdateState) { s.InProgress = false; s.LastCheck = time.Now().Format(time.RFC3339) })

	m, err := fetchUpdateManifest()
	if err != nil {
		setUpdateState(func(s *UpdateState) { s.LastError = err.Error() })
		return
	}
	setUpdateState(func(s *UpdateState) { s.Latest = m.Version })
	if compareVersions(m.Version, helperVersion) <= 0 {
		setUpdateState(func(s *UpdateState) { s.Pending = false })
		return
	}

	// Never interrupt an active browser tunnel. The next periodic/manual check
	// after all proxy tabs are closed will install the helper update.
	for _, g := range groups {
		if g != nil && g.connCount() > 0 {
			setUpdateState(func(s *UpdateState) { s.Pending = true })
			return
		}
	}

	newExe, err := downloadUpdateFile(m)
	if err != nil {
		setUpdateState(func(s *UpdateState) { s.LastError = err.Error(); s.Pending = true })
		return
	}
	setUpdateState(func(s *UpdateState) { s.Pending = true })
	if err := scheduleSelfReplace(newExe); err != nil {
		setUpdateState(func(s *UpdateState) { s.LastError = err.Error() })
		_ = os.Remove(newExe)
	}
}

func autoUpdateLoop(groups ...*GroupState) {
	time.Sleep(15 * time.Second)
	for {
		checkForHelperUpdate(groups...)
		time.Sleep(1 * time.Hour)
	}
}

func main() {
	log.SetFlags(log.LstdFlags | log.Lmicroseconds)
	ibetMember := NewGroupState("ibetMember")
	ibetAgent := NewGroupState("ibetAgent")
	sbobetMember := NewGroupState("sbobetMember")
	sbobetAgent := NewGroupState("sbobetAgent")
	allGroups := []*GroupState{ibetMember, ibetAgent, sbobetMember, sbobetAgent}
	groups := map[string]*GroupState{
		"ibetmember":   ibetMember,
		"ibetagent":    ibetAgent,
		"sbobetmember": sbobetMember,
		"sbobetagent":  sbobetAgent,
	}
	loadPersistedConfig(ibetMember, ibetAgent, sbobetMember, sbobetAgent)

	mux := http.NewServeMux()
	mux.HandleFunc("/status", func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodOptions {
			writeJSON(w, 200, map[string]any{"ok": true})
			return
		}
		writeJSON(w, 200, map[string]any{
			"ok":                      true,
			"version":                 helperVersion,
			"ibetMemberConnections":   ibetMember.connCount(),
			"ibetAgentConnections":    ibetAgent.connCount(),
			"sbobetMemberConnections": sbobetMember.connCount(),
			"sbobetAgentConnections":  sbobetAgent.connCount(),
			"ibetConnections":         ibetMember.connCount() + ibetAgent.connCount(),
			"sbobetConnections":       sbobetMember.connCount() + sbobetAgent.connCount(),
			"update":                  getUpdateState(),
		})
	})
	mux.HandleFunc("/config", func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodOptions {
			writeJSON(w, 200, map[string]any{"ok": true})
			return
		}
		if r.Method != http.MethodPost {
			writeJSON(w, 405, map[string]any{"ok": false})
			return
		}
		var req ConfigRequest
		if err := json.NewDecoder(io.LimitReader(r.Body, 64<<10)).Decode(&req); err != nil {
			writeJSON(w, 400, map[string]any{"ok": false, "error": err.Error()})
			return
		}
		cfg := ProxyConfig{Enabled: req.Enabled, Host: strings.TrimSpace(req.Host), Port: req.Port, User: req.User, Pass: req.Pass}
		if cfg.Enabled && (cfg.Host == "" || cfg.Port < 1 || cfg.Port > 65535) {
			writeJSON(w, 400, map[string]any{"ok": false, "error": "bad proxy config"})
			return
		}
		switch strings.ToLower(strings.TrimSpace(req.Group)) {
		case "ibet":
			ibetMember.setConfig(cfg)
			ibetAgent.setConfig(cfg)
		case "sbobet":
			sbobetMember.setConfig(cfg)
			sbobetAgent.setConfig(cfg)
		default:
			writeJSON(w, 400, map[string]any{"ok": false, "error": "bad group"})
			return
		}
		if err := savePersistedConfig(ibetMember, sbobetMember); err != nil {
			writeJSON(w, 500, map[string]any{"ok": false, "error": "save config: " + err.Error()})
			return
		}
		writeJSON(w, 200, map[string]any{"ok": true, "group": req.Group})
	})
	mux.HandleFunc("/reset", func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodOptions {
			writeJSON(w, 200, map[string]any{"ok": true})
			return
		}
		if r.Method != http.MethodPost {
			writeJSON(w, 405, map[string]any{"ok": false})
			return
		}
		var req ResetRequest
		if err := json.NewDecoder(io.LimitReader(r.Body, 16<<10)).Decode(&req); err != nil {
			writeJSON(w, 400, map[string]any{"ok": false, "error": err.Error()})
			return
		}
		key := strings.ToLower(strings.TrimSpace(req.Group))
		closed := 0
		switch key {
		case "ibet": // legacy reset: close both iBet lanes
			closed += ibetMember.resetConnections()
			closed += ibetAgent.resetConnections()
		case "sbobet": // legacy reset: close both SBOBET lanes
			closed += sbobetMember.resetConnections()
			closed += sbobetAgent.resetConnections()
		default:
			g := groups[key]
			if g == nil {
				writeJSON(w, 400, map[string]any{"ok": false, "error": "bad group"})
				return
			}
			closed = g.resetConnections()
		}
		writeJSON(w, 200, map[string]any{"ok": true, "group": req.Group, "closed": closed})
		allIdle := true
		for _, g := range allGroups {
			if g.connCount() > 0 {
				allIdle = false
				break
			}
		}
		if allIdle && getUpdateState().Pending {
			go checkForHelperUpdate(allGroups...)
		}
	})

	mux.HandleFunc("/update-check", func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodOptions {
			writeJSON(w, 200, map[string]any{"ok": true})
			return
		}
		if r.Method != http.MethodPost && r.Method != http.MethodGet {
			writeJSON(w, 405, map[string]any{"ok": false})
			return
		}
		go checkForHelperUpdate(allGroups...)
		writeJSON(w, 200, map[string]any{"ok": true, "version": helperVersion, "update": getUpdateState()})
	})

	control := &http.Server{Addr: "127.0.0.1:19080", Handler: mux, ReadHeaderTimeout: 5 * time.Second}

	errCh := make(chan error, 5)
	go func() { errCh <- runProxyServer("127.0.0.1:19081", ibetMember) }()
	go func() { errCh <- runProxyServer("127.0.0.1:19082", ibetAgent) }()
	go func() { errCh <- runProxyServer("127.0.0.1:19083", sbobetMember) }()
	go func() { errCh <- runProxyServer("127.0.0.1:19084", sbobetAgent) }()
	go func() {
		log.Printf("control listener on %s", control.Addr)
		errCh <- control.ListenAndServe()
	}()

	go autoUpdateLoop(allGroups...)

	sig := make(chan os.Signal, 1)
	signal.Notify(sig, os.Interrupt, syscall.SIGTERM)
	select {
	case s := <-sig:
		log.Printf("signal: %v", s)
	case err := <-errCh:
		log.Printf("server stopped: %v", err)
	}

	for _, g := range allGroups {
		g.resetConnections()
	}
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	_ = control.Shutdown(ctx)
	fmt.Println("ProxySportHelper stopped")
}
