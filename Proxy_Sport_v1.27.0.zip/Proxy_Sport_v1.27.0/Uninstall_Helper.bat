@echo off
setlocal
set "DEST=%LOCALAPPDATA%\ProxySport"
set "STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\ProxySportHelper.lnk"
taskkill /F /IM ProxySportHelper.exe >nul 2>&1
del /F /Q "%STARTUP%" >nul 2>&1
rmdir /S /Q "%DEST%" >nul 2>&1
echo [OK] Da go Proxy Sport Helper.
pause
