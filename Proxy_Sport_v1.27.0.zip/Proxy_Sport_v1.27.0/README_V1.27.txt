PROXY SPORT V1.27.0

MUC TIEU V1.27
- Tach 4 duong proxy local doc lap:
  IBET MEMBER       -> 127.0.0.1:19081
  AGENT IBET        -> 127.0.0.1:19082
  SBOBET MEMBER     -> 127.0.0.1:19083
  AGENT SBOBET      -> 127.0.0.1:19084
- 2 o proxy tren giao dien van giu nguyen:
  PROXY IBET duoc dung cho ca IBET MEMBER + AGENT IBET.
  PROXY SBOBET duoc dung cho ca SBOBET MEMBER + AGENT SBOBET.
- Moi lane co socket/connection pool rieng. Dong lane nao chi reset lane do.
- Khong reset PAC long vong, khong nip.io, khong delay gia.

CAI / NANG CAP LEN V1.27
1. Giai nen Proxy_Sport_v1.27.0.zip.
2. Chay SETUP_1_LAN.bat 1 LAN de cai Helper V1.27 co 4 lane.
3. Vao chrome://extensions va Load unpacked/Reload PROXY SPORT.
4. Nhap proxy iBet/SBOBET nhu binh thuong.

SAU KHI DA CO HELPER V1.27
- Helper nam tai: %LOCALAPPDATA%\ProxySport
- Helper tu chay cung Windows.
- Helper tu kiem tra cap nhat tu GitHub.
- Cac ban sau neu helper tu cap nhat thanh cong thi khong can chay lai Setup.

LUU Y
- 4 lane tao 4 connection doc lap. Neu proxy Requyet xoay theo connection thi 4 web se co kha nang rat cao nhan IP khac nhau.
- Nha cung cap proxy van co the cap trung mot exit IP theo xac suat; extension khong the dam bao tuyet doi 100% khong bao gio trung neu provider khong cam ket unique IP.

FILE GITHUB
- Proxy_Sport_v1.27.0.zip
- proxy-sport-update.json
- ProxySportHelper.exe
- proxy-sport-helper.json
